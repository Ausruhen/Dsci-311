OK_FORMAT = True

test = {   'name': 'q2_5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.isin(q2_5, [1,2,3])\n'
                                               'array(True)',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
