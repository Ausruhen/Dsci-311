OK_FORMAT = True

test = {   'name': 'q1_3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> sample_proportions(model_proportions, 100).shape[0] == 3\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
