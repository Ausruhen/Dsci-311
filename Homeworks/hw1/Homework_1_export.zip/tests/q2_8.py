OK_FORMAT = True

test = {   'name': 'q2_8',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.isin(type(dugong_7), [float, np.float64, np.float32])\n'
                                               'array(True)',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
