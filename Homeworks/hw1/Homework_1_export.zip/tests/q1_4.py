OK_FORMAT = True

test = {   'name': 'q1_4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> simulated_reds.shape[0] == 1000\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> type(simulated_reds[50]) == np.float64\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
