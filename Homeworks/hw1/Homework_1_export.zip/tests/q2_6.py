OK_FORMAT = True

test = {   'name': 'q2_6',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> np.isin(q2_6, [1,2])\n'
                                               'array(True)',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
